var AWS = require('aws-sdk');
var ses = new AWS.SES({ region: "us-east-1" });
exports.handler = async function (event) {
 console.log(event);
 const s3Object = new AWS.S3({
 apiVersion: "2006-03-01",signatureVersion:"v4"
 });
 const filename = event;
 const bucketparams = { Bucket: process.env.BUCKET_NAME, Key: filename, Expires: parseInt(process.env.EXPIRY_TIME) };
 s3Object.getSignedUrl('getObject', bucketparams, function(err, url) {
    console.log("Test value" +err);
    //console.log(url);
    var responseBody = {
        "location": url
    };
    if(err == null || !err)
    {
        console.log("I am here");
        var params = {
    Destination: {
      ToAddresses: ["r.pattnaik@gmail.com"],
    },
    Message: {
      Body: {
        Text: { Data: JSON.stringify(responseBody) },
      },

      Subject: { Data: "Test Email" },
    },
    Source: "r.pattnaik@gmail.com",
    };
        // Create the promise and SES service object
        var sendPromise = new AWS.SES({apiVersion: '2010-12-01'}).sendEmail(params).promise();
        console.log(JSON.stringify(responseBody));
        sendPromise.then(
          function(data) {
            console.log(data.MessageId);
          }).catch(
            function(err) {
            console.error(err, err.stack);
          });
    }
    else
    {
        console.log(new Error(err));
    }
});
};
